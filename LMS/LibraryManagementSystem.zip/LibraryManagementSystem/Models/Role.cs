﻿namespace LibraryManagementSystem.Models
{
    public class Role
    {
        public const string Librarian = "Librarian";
        public const string Member = "Member";
    }
}
